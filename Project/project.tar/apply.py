'''
python version: 3.7
apply py used to calculate the sample mean in random mode of section 5.2
'''
import project
import numpy as np
import random
import math
import sys

mode = "random"
lamda = 9.72
alpha1 = 0.01
alpha2 = 0.4
beta = 0.86
v1 = 1.2
v2 = 1.47
time_end = 1500.00
fogTimeToCloudTime = 0.6
fogTimeLimit = float(sys.argv[1])

transient_seq = 4000

T_i = list()

for seed in range(0, 61):
    random.seed(seed)
    np.random.seed(seed)
    arrival = list()
    t = 0
    while t < time_end:                                                 # generate arrival time in random mode (especially must have one element big than timeLimit)
        item = random.expovariate(lamda)
        if item == 0:
            continue
        t += item
        if t >= time_end:
            break
        arrival.append(t)

    service = list()                                                    # generate service time in random mode (size as same as arrival)
    x = list()
    i = 0
    while i < len(arrival):
        item = np.random.uniform(0, 1, 1).tolist()[0]
        if item != 0:
            i += 1
            x.append(float(item))
    service = [(i*(alpha2**(1-beta) - alpha1**(1-beta)) + alpha1**(1-beta))**(1/(1-beta)) for i in x]
                                                                       #The network latency is uniformly distributed in the open interval (?1, ?2) where ?2 > ?1 > 0.
    network = list()
    i = 0
    while i < len(arrival):
        item = np.random.uniform(v1, v2, 1).tolist()[0]
        if item != v1:
            i += 1
            network.append(item)
    response_dict = project.simulation(mode, arrival, service, network, fogTimeLimit, fogTimeToCloudTime, time_end)

    argu = list()
    for key in sorted(response_dict.keys()):
        argu.append(response_dict[key] - key)
    #project.draw(argu)

    # transient part data remove, mean response time = (x(m+1) + x(m+2) + .... + x(N)) / (N - m)
    argu = argu[transient_seq:]
    mean = sum(argu) / len(argu)
    print(f"mean response time after remove transient: {mean}")

    T_i.append(mean)
    
f = open("T_" + str(fogTimeLimit) + ".txt", 'w')
for item in T_i:
    f.write(f"{item}\n")
f.close()

T = sum(T_i) / len(T_i)
print(f"mean response T^ is: {T}")

S = 0
for _ in range(len(T_i)):
    S += (T - T_i[_])**2
S = S / (len(T_i) - 1)
S = math.sqrt(S)
print(f"Standard deviation: {S}")
print(f"confidence interval is [{T - 2 * S / math.sqrt(61):.4f}, {T + 2 * S / math.sqrt(61):.4f}]")

f = open("confidence_interval.txt", 'a')
f.write(f"{fogTimeLimit}\t{T - 2 * S / math.sqrt(61)}\t{T + 2 * S / math.sqrt(61)}\n")
f.close()