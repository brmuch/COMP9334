from math import sqrt

f_1 = open("T_0.1.txt", 'r')
f_2 = open("T_0.11.txt", 'r')

Ti = list()

while True:
    data1 = f_1.readline().strip('\n')
    data2 = f_2.readline().strip('\n')

    if data1 == '':
        break
    Ti.append(float(data1) - float(data2))

T = sum(Ti) / len(Ti)

S = 0
for i in range(len(Ti)):
    S += (T - Ti[i]) ** 2

S = S / (len(Ti) - 1)
S = sqrt(S)

print(f"confidence interval is: [{T - 2 * S / sqrt(len(Ti))}, {T + 2 * S / sqrt(len(Ti))}]")
f_1.close()
f_2.close()