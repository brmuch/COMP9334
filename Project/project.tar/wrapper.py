import project
import numpy as np
import random

mode_f = "mode_"
para_f = "para_"
arrival_f = "arrival_"
service_f = "service_"
network_f = "network_"
suffix = ".txt"

f = open("num_tests.txt", 'r')
number_of_test = int(str(f.readline()).strip('\n'))
f = f.close()

for i in range(number_of_test):
    project.file_No = i + 1
    # Read in the configuration files for the test_index    
    f_mode = open(mode_f + str(i + 1) + suffix, 'r')
    f_para = open(para_f + str(i + 1) + suffix, 'r')
    f_arrival = open(arrival_f + str(i + 1) + suffix, 'r')
    f_service = open(service_f + str(i + 1) + suffix, 'r')
    f_network = open(network_f + str(i + 1) + suffix, 'r')
    # Set the simulation mode and parameter values
    mode = f_mode.read().strip('\n')
    
    if mode == "trace":                                                     # trace mode
        fogTimeLimit = float(f_para.readline().strip('\n'))                             # para_*.txt
        fogTimeToCloudTime = float(f_para.readline().strip('\n'))
        
        arrival = list()                                                                # arrival_*.txt
        while True:
            data = f_arrival.readline().strip('\n')
            if len(data) != 0:
                arrival.append(float(data))
            else:
                break
        
        service = list()                                                                # service_*.txt
        while True:
            data = f_service.readline().strip('\n')
            if len(data) != 0:
                service.append(float(data))
            else:
                break
        
        network = list()                                                                # network_*.txt
        while True:
            data = f_network.readline().strip('\n')
            if len(data) != 0:
                network.append(float(data))
            else:
                break

        project.simulation(mode, arrival, service, network, fogTimeLimit, fogTimeToCloudTime, float("inf"))

    elif mode == "random":                                                  # random mode
        fogTimeLimit = float(f_para.readline().strip('\n'))                             # para_*.txt
        fogTimeToCloudTime = float(f_para.readline().strip('\n'))
        time_end = float(f_para.readline().strip('\n'))
        
        lamda = float(f_arrival.readline().strip('\n'))                                 # arrival_*.txt
        alpha1 = float(f_service.readline().strip('\n'))                                # service_*.txt
        alpha2 = float(f_service.readline().strip('\n'))
        beta = float(f_service.readline().strip('\n'))

        v1 = float(f_network.readline().strip('\n'))                                    # network_*.txt
        v2 = float(f_network.readline().strip('\n'))

        # generate arrival time && service time && network latency here
        np.random.seed(project.seed)
        random.seed(project.seed)
        arrival = list()
        t = 0
        while t < time_end:                                                                                   # generate arrival time in random mode (especially must have one element big than timeLimit)
            item = random.expovariate(lamda)
            if item == 0:
                continue
            t += item
            if t >= time_end:
                break
            arrival.append(t)

        service = list()                                                                                       # generate service time in random mode (size as same as arrival)
        x = list()
        i = 0
        while i < len(arrival):
            item = np.random.uniform(0, 1, 1).tolist()[0]
            if item != 0:
                i += 1
                x.append(float(item))
        service = [(i*(alpha2**(1-beta) - alpha1**(1-beta)) + alpha1**(1-beta))**(1/(1-beta)) for i in x]
                                                                                                               #The network latency is uniformly distributed in the open interval (?1, ?2) where ?2 > ?1 > 0.
        network = list()
        i = 0
        while i < len(arrival):
            item = np.random.uniform(v1, v2, 1).tolist()[0]
            if item != v1:
                i += 1
                network.append(item)

        response_dict = project.simulation(mode, arrival, service, network, fogTimeLimit, fogTimeToCloudTime, time_end)
    else:
        pass

    # Call simulation function
    # simulation()                    
    # Write the output files in project.py
    # mrt_*.txt, fog_dep_*.txt, net_dep_*.txt and cloud_dep_*. 