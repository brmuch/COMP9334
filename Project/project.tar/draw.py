# python version: python 3.7
import matplotlib.pyplot as plt 

x = [0.01, 0.04, 0.05, 0.07, 0.08, 0.09, 0.1, 0.11, 0.12, 0.13, 0.14, 0.15, 0.16]
y1 = list()                                         # seed = 0
y2 = list()                                         # seed = 1
y3 = list()                                         # seed = 2
y4 = list()                                         # seed = 3
y5 = list()                                         # seed = 4
y6 = list()                                         # seed = 5
y7 = list()                                         # seed = 6
  
for item in x:
    f = open("T_" + str(item) + ".txt", 'r')
    for i in range(0, 7):
        number = f.readline().strip('\n')
        if i == 0:
            y1.append(float(number))
        elif i == 1:
            y2.append(float(number))
        elif i == 2:
            y3.append(float(number))
        elif i == 3:
            y4.append(float(number))
        elif i == 4:
            y5.append(float(number))
        elif i == 5:
            y6.append(float(number))
        else:
            y7.append(float(number))
    f.close()

plt.plot(x, y1, color="r", label="seed = 0")
plt.plot(x, y2, color="b", label="seed = 1")
plt.plot(x, y3, color="y", label="seed = 2")
plt.plot(x, y4, color="green", label="seed = 3")
plt.plot(x, y5, color="skyblue", label="seed = 4")
plt.plot(x, y6, label= "seed = 5", color="azure")
plt.plot(x, y7, label= "sedd = 6", color="pink")
plt.legend()
plt.xlabel("time")
plt.ylabel("mean response time")
plt.show()

